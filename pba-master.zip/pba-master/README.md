# pba
Parralel Bundle Adjustment


* This is clean code derived from http://grail.cs.washington.edu/projects/mcba/ (v1.0.5)

Some Changes:

 - CMake infrastructure.
 - Fixed AVX2 for GCC / Linux.
 - No compile warns, clean code.
